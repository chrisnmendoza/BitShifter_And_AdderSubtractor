#! /bin/sh

. ../../testenv.sh

analyze compile_error.vhdl
clean

echo "Test successful"
