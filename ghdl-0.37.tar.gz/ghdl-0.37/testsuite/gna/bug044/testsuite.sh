#! /bin/sh

. ../../testenv.sh

analyze_failure aggr1.vhdl

clean

echo "Test successful"
