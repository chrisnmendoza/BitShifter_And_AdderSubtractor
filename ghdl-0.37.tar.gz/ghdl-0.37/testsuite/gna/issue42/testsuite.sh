#! /bin/sh

. ../../testenv.sh

analyze_failure bugreport_attribute.vhdl

clean

echo "Test successful"
