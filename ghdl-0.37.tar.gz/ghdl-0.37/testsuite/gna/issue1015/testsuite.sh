#! /bin/sh

. ../../testenv.sh

analyze_failure std.vhdl

clean

echo "Test successful"
