#! /bin/sh

. ../../testenv.sh

analyze_failure test.vhdl

clean

echo "Test successful"
