#! /bin/sh

. ../../testenv.sh

#echo "Skipped !!!!!!!!"
#exit 0

analyze_failure 20597.vhd

clean

echo "Test successful"
