#! /bin/sh

. ../../testenv.sh

analyze_failure t.vhdl

clean

echo "Test successful"
