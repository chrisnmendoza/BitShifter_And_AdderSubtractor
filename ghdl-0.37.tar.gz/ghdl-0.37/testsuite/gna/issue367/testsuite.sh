#! /bin/sh

. ../../testenv.sh

analyze_failure e.vhdl

clean

echo "Test successful"
