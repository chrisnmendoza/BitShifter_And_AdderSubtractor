#! /bin/sh

. ../../testenv.sh

analyze_failure tb.vhdl

clean

echo "Test successful"
