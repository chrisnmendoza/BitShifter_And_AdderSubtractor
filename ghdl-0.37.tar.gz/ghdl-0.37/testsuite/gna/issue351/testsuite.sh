#! /bin/sh

. ../../testenv.sh

analyze_failure mypkg.vhdl

clean

echo "Test successful"
