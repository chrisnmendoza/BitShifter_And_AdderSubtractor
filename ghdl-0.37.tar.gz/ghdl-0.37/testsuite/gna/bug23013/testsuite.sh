#! /bin/sh

. ../../testenv.sh

analyze_failure attrs.vhdl

clean

echo "Test successful"
