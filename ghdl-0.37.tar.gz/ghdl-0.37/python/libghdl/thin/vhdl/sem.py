from libghdl import libghdl

Semantic = libghdl.vhdl__sem__semantic
