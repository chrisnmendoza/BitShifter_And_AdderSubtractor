#! /bin/sh

. ../../testenv.sh

analyze_failure loopy.vhdl

clean

echo "Test successful"
