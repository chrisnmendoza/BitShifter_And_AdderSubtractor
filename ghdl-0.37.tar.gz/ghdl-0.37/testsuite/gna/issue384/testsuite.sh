#! /bin/sh

. ../../testenv.sh

analyze yy.vhdl

clean

echo "Test successful"
