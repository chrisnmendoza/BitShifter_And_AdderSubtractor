#! /bin/sh

. ../../testenv.sh

analyze_failure cnt.vhdl

clean

echo "Test successful"
