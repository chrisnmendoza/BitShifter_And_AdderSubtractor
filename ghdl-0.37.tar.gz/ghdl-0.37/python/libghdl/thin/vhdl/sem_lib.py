from libghdl import libghdl

Load_File = libghdl.vhdl__sem_lib__load_file

Finish_Compilation = libghdl.vhdl__sem_lib__finish_compilation

Free_Dependence_List = libghdl.vhdl__sem_lib__free_dependence_list
