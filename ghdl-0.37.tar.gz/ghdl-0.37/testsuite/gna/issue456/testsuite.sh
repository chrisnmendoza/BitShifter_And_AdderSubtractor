#! /bin/sh

. ../../testenv.sh

analyze pkg.vhdl

clean

echo "Test successful"
